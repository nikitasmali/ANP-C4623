package com.airline.service;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;

import com.airline.entity.Admin;
import com.airline.model.AdminDTO;
import com.airline.repository.AdminRepository;
import com.airline.util.Converter;

@SpringBootTest
class AdminServiceTest {

	@Autowired
	private AdminService adminService;
	
	@Autowired
	private Converter converter;
	
	@MockBean
	private AdminRepository adminRepository;
	
	//this will test save Admin details
	@Test
	@DisplayName("Positive Test Case")
	void testSaveAdmin()
	{
		Admin admin = Admin.builder().name("shawin").email("shawin@gmail.com").
				userName("admin").password("admin123").role("admin").build();
		
		Mockito.when(adminRepository.save(admin)).thenReturn(admin);
		 AdminDTO aDTO = converter.convertToAdminDTO(admin);
		 AdminDTO adto=adminService.createAdmin(admin);
		assertEquals(adto.getName(), admin.getName());
	}
	
	
	@Test
	void testGetAllAdmins()
	{
		Admin admin = Admin.builder().name("shawin").email("shawin@gmail.com").
				userName("admin").password("admin123").role("admin").build();
		Admin admin1 = Admin.builder().name("nilanjan").email("nil@gmail.com").
				userName("admin").password("admin123").role("admin").build();
		
		List<Admin> list = new ArrayList<>();
		list.add(admin1);
		list.add(admin);
		
		Mockito.when(adminRepository.findAll()).thenReturn(list);
		
		List<AdminDTO> adto= adminService.getAllAdmin();
		
		List<Admin> ad = new ArrayList<Admin>();
		adto.forEach(a->{
			ad.add(converter.convertToAdminEntity(a));
		});
		
		assertThat(ad).isEqualTo(list);
	}
	
	
	@Test
	@DisplayName("Negative Test Case")
	void testNegativeGetAdminById()
	{
		Admin admin2 = Admin.builder().name("shawin").email("shawin@gmail.com").
				userName("admin").password("admin123").role("admin").build();
		
		Optional<Admin> opAd= Optional.of(admin2);
	   Mockito.when(adminRepository.findById(admin2.getId())).thenReturn(opAd);
	   
	   AdminDTO aDto = converter.convertToAdminDTO(admin2);
	   assertThat(adminService.getAdminById(admin2.getId())).isEqualTo(aDto);
	
	}
}
