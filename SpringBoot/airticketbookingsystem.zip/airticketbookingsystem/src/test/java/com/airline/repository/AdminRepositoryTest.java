package com.airline.repository;

import static org.assertj.core.api.Assertions.assertThat;

import java.util.List;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.MethodOrderer;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;

import com.airline.entity.Admin;


@DataJpaTest
@AutoConfigureTestDatabase(replace = AutoConfigureTestDatabase.Replace.NONE)
@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
public class AdminRepositoryTest {

	@Autowired
	AdminRepository adminRepository;
	
	@Test
	void saveAdminTest()
	{
		Admin admin = Admin.builder().name("saquib").email("saquib@gmail.com").
				userName("admin").password("admin123").role("admin").build();
		
		Admin a = adminRepository.save(admin);
		assertThat(a.getName()).isEqualTo("saquib");
	}
	
	@Test
	void getAllAdminsTest()
	{
		List<Admin> list = adminRepository.findAll();
		assertThat(list.size()).isGreaterThan(0);
	}
	
	@Test
	@DisplayName("Negative Test Case")
	void updateAdminTest()
	{
		Admin admin = Admin.builder().name("saquib").email("saquib@gmail.com").
				userName("admin").password("admin123").role("admin").build();
		admin.setName("pallab");
		Admin aa = adminRepository.save(admin);
		assertThat(aa.getName()).isEqualTo("saquib");
	}
}
