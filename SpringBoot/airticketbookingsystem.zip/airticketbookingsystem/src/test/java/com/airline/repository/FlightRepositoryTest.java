package com.airline.repository;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

import java.time.LocalDate;
import java.util.NoSuchElementException;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.MethodOrderer;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;

import com.airline.entity.Flight;

@DataJpaTest
@AutoConfigureTestDatabase(replace = AutoConfigureTestDatabase.Replace.NONE)
@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
public class FlightRepositoryTest {

	@Autowired
	FlightRepository flightRepository;
	
	@Test
	void saveFlight()
	{
		Flight flight = Flight.builder().availableSeats(20).totalSeats(100).
				date(LocalDate.parse("2022-11-10")).time("10:30").source("kolkata").
				destination("bangalore").travellerClass("business").build();
		
		Flight f = flightRepository.save(flight);
		assertEquals(f.getFlightId(), flight.getFlightId());
	}
	
	@Test
	void deleteFlight()
	{
		flightRepository.deleteById(7);
		assertThrows(NoSuchElementException.class,()-> flightRepository.findById(7).get());
	}
	
	@Test
	@DisplayName("Negative Test Case")
	void updateFlightTest()
	{
		Flight flight = Flight.builder().availableSeats(20).totalSeats(100).
				date(LocalDate.parse("2022-11-10")).time("10:30").source("kolkata").
				destination("bangalore").travellerClass("business").build();
		
		flight.setAvailableSeats(15);
		Flight f = flightRepository.save(flight);
		assertEquals(f.getAvailableSeats(), 20);
	}
}
